wo= 0:pi/100:2*pi;
y = cos(wo/2*T);
plot(x,y)
pi*t