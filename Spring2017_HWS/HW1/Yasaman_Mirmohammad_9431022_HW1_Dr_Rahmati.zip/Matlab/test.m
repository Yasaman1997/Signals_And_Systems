clc
clear all
x=0:1:40;
y=10*sin(2*pi*x/15);
subplot(2,1,1)
plot(x,y) %CT
title('CT sine wave')
grid
subplot(2,1,2)
stem(x,y) %DT
title('DT sine wave')
grid


hold


m = @(t) cos(2*pi*9*t) .* ((t > 0 ) & (t < 3));
t = linspace(-1, 4, 500);
Out = m(t);
figure(2)
plot(t, Out)
grid