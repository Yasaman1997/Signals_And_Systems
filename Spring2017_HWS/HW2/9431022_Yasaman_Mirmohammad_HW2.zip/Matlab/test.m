
x2 =[0 1 2 3 -2];
%t2=input('Enter the starting time of second sequence t2 = ');

l2=length(x2);

%a=t2+l2-1;
%t=t2:a;
%subplot(312);
stem(x2);
grid on;
xlabel('time');
ylabel('amplitude');
